
// --- Config ---
// Coordinates for Chesley, ON (approx). Verify and adjust if needed.
const CHESLEY = { lat: 44.301, lng: -81.102 };
const DELIVERY_RADIUS_KM = 30;
// Pricing
const PRICES = { standard: 170, flush: 230 };
// Endpoint to send orders (use a webhook from Make/Zapier/Apps Script, etc.)
const ENDPOINT_URL = ""; // e.g., "https://hook.integromat.com/XXXXX"

// --- Helpers ---
const $ = (sel) => document.querySelector(sel);
const form = $("#orderForm");
const dateInput = $("#dateNeeded");
const jobLocationEl = $("#jobLocation");
const rememberEl = $("#rememberMe");
const geoNotice = $("#geoNotice");

// Haversine distance in KM
function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

// Try to geocode with browser if possible (fallback simple guess)
async function geocodeAddress(addr) {
  // If Google Places is loaded and the user picked a Place, rely on it via hidden fields (not implemented here).
  // As a fallback, attempt the free Nominatim endpoint is not allowed client-side without CORS guarantees.
  // So we return null and only warn; on your backend, you should geocode precisely.
  return null;
}

// Rough client-side filter: if user allows location on device at the job site
async function distanceFromDeviceToChesley() {
  return new Promise((resolve) => {
    if (!navigator.geolocation) return resolve(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const d = haversine(pos.coords.latitude, pos.coords.longitude, CHESLEY.lat, CHESLEY.lng);
        resolve(d);
      },
      () => resolve(null),
      { enableHighAccuracy: false, timeout: 4000 }
    );
  });
}

function setNotice(kind, msg) {
  geoNotice.classList.remove("hidden", "bad", "good");
  if (kind === "bad") geoNotice.classList.add("bad");
  if (kind === "good") geoNotice.classList.add("good");
  geoNotice.textContent = msg;
}

function clearNotice() {
  geoNotice.classList.add("hidden");
  geoNotice.textContent = "";
}

// Persist billing info locally
const STORAGE_KEY = "pottypal.billing.v1";
function saveBilling() {
  if (!rememberEl.checked) return;
  const data = {
    name: form.name.value,
    company: form.company.value,
    billingAddress: form.billingAddress.value,
    email: form.email.value,
    phone: form.phone.value,
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}
function loadBilling() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return;
  try {
    const d = JSON.parse(raw);
    ["name","company","billingAddress","email","phone"].forEach(k => {
      if (d[k]) form[k].value = d[k];
    });
  } catch {}
}
function clearBilling() {
  localStorage.removeItem(STORAGE_KEY);
  ["name","company","billingAddress","email","phone"].forEach(k => form[k].value = "");
}

// Install PWA
let deferredPrompt;
const installBtn = document.getElementById("installBtn");
window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  deferredPrompt = e;
  installBtn.style.display = "inline-flex";
});
installBtn?.addEventListener("click", async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt = null;
  installBtn.style.display = "none";
});

// Validate radius (best-effort client-side)
async function validateRadius() {
  clearNotice();
  const deviceDist = await distanceFromDeviceToChesley();
  if (deviceDist !== null) {
    if (deviceDist <= DELIVERY_RADIUS_KM) {
      setNotice("good", `Looks good: ~${deviceDist.toFixed(1)} km from Chesley.`);
      return true;
    } else {
      setNotice("bad", `Heads up: You appear to be ~${deviceDist.toFixed(1)} km from Chesley (outside the ~${DELIVERY_RADIUS_KM} km area). You can still submit; we’ll confirm availability.`);
      return false;
    }
  }
  // If geolocation not available, leave to backend check
  setNotice("", "Couldn’t check your distance automatically. Submit anyway; we’ll confirm if the location is within ~30 km.");
  return true;
}

// Handle submit
form.addEventListener("submit", async (e) => {
  e.preventDefault();

  // Basic validation
  const units = parseInt(form.units.value || "0", 10);
  if (units < 1) {
    alert("Please enter at least 1 unit.");
    return;
  }

  const unitType = form.unitType.value;
  const price = PRICES[unitType] * units;

  // Optional radius check (non-blocking)
  await validateRadius();

  // Save billing
  saveBilling();

  // Build payload
  const payload = {
    source: "pottypal-pwa",
    timestamp: new Date().toISOString(),
    billing: {
      name: form.name.value,
      company: form.company.value,
      billingAddress: form.billingAddress.value,
      email: form.email.value,
      phone: form.phone.value,
    },
    job: {
      jobLocation: form.jobLocation.value,
      dateNeeded: form.dateNeeded.value,
      units,
      unitType,
      monthlyPriceCAD: PRICES[unitType],
      estMonthlySubtotalCAD: price,
      notes: form.notes.value
    },
    radiusKm: DELIVERY_RADIUS_KM,
    chesley: CHESLEY
  };

  // Send somewhere
  try {
    if (ENDPOINT_URL) {
      const res = await fetch(ENDPOINT_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error(`HTTP {res.status}`);
      alert("Thanks! Your order has been submitted. We’ll confirm shortly.");
      form.reset();
      loadBilling(); // re-fill stored billing
      clearNotice();
    } else {
      // Fallback: mailto link prefilled (not ideal, but works without backend)
      const subject = encodeURIComponent("New Scotty’s Pottys Order via PottyPal");
      const body = encodeURIComponent(JSON.stringify(payload, null, 2));
      window.location.href = `mailto:scottyspottys11@gmail.com?subject=${subject}&body=${body}`;
    }
  } catch (err) {
    console.error(err);
    alert("Sorry—couldn’t submit right now. Please try again or call 519-706-6000.");
  }
});

// Clear button
document.getElementById("clearBtn").addEventListener("click", () => {
  if (confirm("Clear saved billing info from this device?")) {
    clearBilling();
    alert("Saved info cleared from this device.");
  }
});

// Init
loadBilling();

// Register service worker
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("service-worker.js"));
}
