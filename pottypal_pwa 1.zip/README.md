
# Scotty’s Pottys – PottyPal (PWA)

A lightweight booking PWA intended to live on your Shopify site. Contractors can save their billing info locally (no credit card), pick a job location, date, units, and unit type, and submit in seconds.

## What it does
- **Saves billing info on the device** using `localStorage` so repeat orders are fast.
- **30 km radius check** (best-effort client-side using device location). Shows a notice if outside.
- **No payment**—just collects details and sends to your email or webhook.
- **PWA**—installable on phones, offline caching of the app shell.

## Files
- `index.html` – the form UI.
- `styles.css` – clean, mobile-first UI.
- `app.js` – localStorage, distance check, and submission.
- `manifest.json` – PWA manifest.
- `service-worker.js` – caches files for offline.
- `assets/logo.png` – placeholder (replace with your actual logo).

## Distance Check
The app uses approximate coordinates for **Chesley, ON** (44.301, -81.102). Update these if you want exact shop coords:
```js
const CHESLEY = { lat: 44.301, lng: -81.102 };
```
A backend should **re-validate** distance precisely when the order arrives.

## Submission Options
By default, if `ENDPOINT_URL` in `app.js` is empty, the app opens a prefilled **mailto:** to `scottyspottys11@gmail.com`.

For production, set `ENDPOINT_URL` to any webhook (Make/Zapier/Apps Script/Cloudflare Worker) that emails the payload to you and/or writes to a Google Sheet.

### Example: Google Apps Script (Email + Sheet)
1. Go to **script.new**, paste the following:
```js
function doPost(e){
  var data = JSON.parse(e.postData.contents);
  MailApp.sendEmail("scottyspottys11@gmail.com", "New PottyPal Order", JSON.stringify(data, null, 2));
  // Optional: write to a Google Sheet
  // const ss = SpreadsheetApp.openById("SHEET_ID");
  // ss.getSheetByName("Orders").appendRow([new Date(), data.billing.name, data.billing.email, data.job.jobLocation, data.job.dateNeeded, data.job.units, data.job.unitType, data.job.estMonthlySubtotalCAD]);
  return ContentService.createTextOutput(JSON.stringify({ok:true})).setMimeType(ContentService.MimeType.JSON);
}
```
2. **Deploy → New deployment → Web app**, set "Anyone" access, copy the URL.
3. Put that URL into `ENDPOINT_URL` in `app.js`.

## Shopify Setup
1. In Shopify admin, go to **Content → Files** and upload the entire contents of this folder (or host on your domain under `/pottypal/`). Alternatively, add these files to your **theme assets** via the code editor.
2. Create a new **page** called “Book a Toilet”.
3. Edit the page content and add a simple embed:
```html
<div id="pottypal-root"></div>
<script src="/pottypal/app.js" defer></script>
<link rel="stylesheet" href="/pottypal/styles.css">
<link rel="manifest" href="/pottypal/manifest.json">
```
   Or, paste the full `index.html` into a minimal **custom page template**.
4. Ensure the store is served via **HTTPS** (Shopify does this), so PWA features work.
5. Replace `assets/logo.png` with your actual logo (maintain same path/name) for icons.

## Optional: Google Places Autocomplete
Uncomment the Google Maps script tag in `index.html` (add your API key) and wire up an `Autocomplete` on the `#jobLocation` field for cleaner addresses.

## Pricing
Update in `app.js` if needed:
```js
const PRICES = { standard: 170, flush: 230 };
```

## Support
If something breaks, the app shows a fallback **mailto** and your **phone number (519-706-6000)** so a contractor can still reach you.
